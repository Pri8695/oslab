clear
ch=1
while [ $ch = 1 ]
do
echo 'Enter the number'
read num

if [ $num = quit ]
then
ch=0

elif [ $num -lt 50 ]
then
echo `expr $num \* $num`

else
echo 'Enter a number below 50'

fi
done


