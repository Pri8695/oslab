clear
echo 'Enter the file name'
read nam

w=` cat $nam | wc -w `

echo 'The number of words in the file are'
echo $w
