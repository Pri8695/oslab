clear
echo 'Enter the file name'
read nam

l=` grep -c "." $nam `
echo $l


