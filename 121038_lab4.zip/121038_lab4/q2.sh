clear
echo 'Enter the string'
read str

if grep -q $str file.txt
then
echo 'Found'

else
echo 'Not Found'

fi

