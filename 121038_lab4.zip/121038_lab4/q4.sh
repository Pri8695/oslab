clear

echo 'Enter the number'
read num

i=2
n=` expr $num - 1 `
ch=1

while [ $i \< $num ]
do

r=` expr $num \% $i `
i=` expr $i + 1 `

if [ $r = 0 ]
then
ch=0

fi
done

if [ $ch = 1 ]
then
echo 'Prime Number'

else
echo 'Not a prime number'

fi
