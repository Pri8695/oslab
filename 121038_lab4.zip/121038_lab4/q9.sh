clear
echo 'Enter the file name'
read nam

cnt=0
c=` cat $nam | wc -c `
i=0
j=` expr $c - 1 `
while [ $i \< $j ]
do
        n=1
        line=`head -$i $nam|tail -1`
        ch=`echo $line|cut -c $n`
        while [ "$ch" != "" ]
        do
                if [ "$ch" = " " ]
                then
                cnt=`expr $cnt + 1`
                fi
                n=`expr $n + 1`
                ch=`echo $line|cut -c $n`

        done
done
echo no. of space
echo $cnt
