clear
echo 'Enter a number'
read n

s=` expr $n - 1 `
d=` expr $s \/ 2 `
f=` expr $d \* $n `

echo $f

