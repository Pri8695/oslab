clear

echo 'Enter your salary'
read sal

hr=` expr $sal \* 10 `
hra=` expr $hr \/ 100 `

echo 'Your HRA is'
echo $hra
