clear

ti=$(date +"%H")

echo $ti

if [ $ti -lt 12 ]
then
echo 'Good Morning'

elif [ $ti -lt 16 ]
then
echo 'Good evening'

else
echo 'Good night'

fi
