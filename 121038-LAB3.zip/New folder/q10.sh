clear
ch=0

x[0]=1
x[1]=2
x[2]=3
x[3]=4
x[4]=5

echo list is ${x[@]}

echo 'Enter the number to be found'
read num

for i in { 0..5 }
do
if [ $x[i] = $num ]
then
echo 'Number found in list'
echo 'Its position is'
echo $i
exit

else
ch=1

fi
done

if [ $ch = 1]
echo 'Number not found'

fi
