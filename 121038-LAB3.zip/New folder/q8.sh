clear
i=1
j=1
echo 'Enter till when should the series run'
read limit

echo $i
echo $j

for x in { 2..$limit }
do
f=`expr $i + $j`
i=$j
j=$f

echo $j
done



