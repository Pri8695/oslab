clear
echo 'Addition:'
echo `expr $1 + $2`
echo 'Subtraction:'
echo `expr $1 - $2`
echo 'Division:'
echo `expr $1 \/ $2`
echo 'Multiplication:'
echo `expr $1 \* $2`
echo 'Modulo:'
echo `expr $1 \% $2`
