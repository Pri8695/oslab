clear
while [ 1 ]
do

echo 'Enter the number'
read num

if [ $num \< 50 ]
then
echo `expr $num \* $num`

else
echo 'Enter another number less than 50'

fi
done

