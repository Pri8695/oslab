clear
echo 'enter a number'
read a 
echo 'enter another number'
read b

if [ $a = $b ]
then 
echo 'Both numbers are equal'

elif [ $a \> $b ]
then
echo 'First number is greater'

elif [ $b \> $a ]
then
echo 'Second number is greater'

fi
