clear
ch=1
while [ $ch = 1 ]
do
echo 'Enter the word'
read word

case $word in

Jan) echo 'January' ;;
Janu) echo 'January' ;;
Janua) echo 'January' ;;
January) echo 'January' ;;
Quit) ch=0 ;;
*) echo 'Invalid input' ;;

esac
done
