clear
echo 'Enter the command'
read comm

$comm
