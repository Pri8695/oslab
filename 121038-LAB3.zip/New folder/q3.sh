clear
echo 'enter a number'
read a 
echo 'enter another number'
read b

echo 'choose your operation'
echo '1	Add'
echo '2	Subtract'
echo '3	Divide'
echo '4	Multiply'
echo '5	Modulo'
echo 'enter your operand'
read ch

case $ch in
1)  echo `expr $a + $b` ;;
2)  echo `expr $a - $b` ;;
3)  echo `expr $a \/ $b` ;;
4)  echo `expr $a \* $b` ;;
5)  echo `expr $a % $b` ;;
*)  echo 'invalid choice' ;;

esac

