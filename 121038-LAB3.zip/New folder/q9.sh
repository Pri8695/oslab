clear
while [ 1 ]
do
echo 'Enter the capital of Gujarat'
read ans

str='Gandhinagar'
str1='gandhinagar'

if [ $ans = $str ]
then 
echo 'Correct'
exit

elif [ $ans = $str1 ]
then
echo 'Correct'
exit

else
echo 'Enter the correct capital of Gujarat'

fi
done

