clear

while [ 1 ]
do

echo 'Enter the capital of Gujarat'
read answer

str='Gandhinagar'

if [ $answer = $str ]
then 
echo 'Correct'
exit

fi

done

