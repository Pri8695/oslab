clear

echo 'Enter the command'
read com

$com
