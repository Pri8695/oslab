clear

while [ 1 ]
do

echo 'Enter the number'
read n

if [ $n \< 50 ]
then
echo `expr $n \* $n`

else
echo 'Enter a number less than 50'

fi

done

