clear
echo 'enter a number'
read a 
echo 'enter another number'
read b

if [ $a = $b ]
then 
echo 'numbers are equal'

elif [ $a \> $b ]
then
echo 'a is greater'

elif [ $b \> $a ]
then
echo 'b is greater'

fi
