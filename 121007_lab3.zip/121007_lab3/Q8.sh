clear

i=1
j=1

echo 'Enter the range'
read range

echo $i
echo $j

for z in { 2..$range }
do
sum=`expr $i + $j`
i=$j
j=$sum

echo $j

done



