clear
echo 'enter a number'
read a 
echo 'enter another number'
read b

echo 'Addition:'
echo `expr $a + $b`
echo 'Subtraction:'
echo `expr $a - $b`
echo 'Division:'
echo `expr $a \/ $b`
echo 'Multiplication:'
echo `expr $a \* $b`
echo 'Remainder'
echo `expr $a % $b`
