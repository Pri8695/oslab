clear
y=0
x=(1 2 3 4 5 6 7)

echo 'Enter the number to be found'
read num

for i in { 0..7 }
do
if [ $x[i] = $num ]
then
echo 'Number found in list'
echo 'Its position is'
echo $i
exit

else
y=1

fi
done

if [ $y = 1]
echo 'Number not found'

fi
