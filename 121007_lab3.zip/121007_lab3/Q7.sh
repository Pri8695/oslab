clear

choice=1

while [ $choice = 1 ]
do

echo 'Enter the word'
read wrd

case $wrd in

Jan) echo 'January' ;;
Janu) echo 'January' ;;
Janua) echo 'January' ;;
January) echo 'January' ;;
quit) choice=0 ;;
*) echo 'Invalid' ;;

esac

done
