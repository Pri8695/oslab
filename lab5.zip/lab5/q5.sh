clear

echo 'Enter the file'
read fl

if [ -f $fl ];
then
echo 'File exists'
echo 'Enter the file that has to be appanded'
read fl1
cat $fl >> $fl1

else
echo 'File does not exist'

fi


