clear

echo 'Enter the string to be checked'
read str

str1=` expr $str | rev `

if [ $str1 = $str ]
then
echo 'It is a palindrome string'

else
echo 'It is not a palindrome string'

fi


