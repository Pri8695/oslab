clear

num=$1
str=$2

i=0

while [ $i -lt $num ]
do
echo $str
i=` expr $i + 1 `
done
