clear

echo $1 | rev

