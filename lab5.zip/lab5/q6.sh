clear

num=$1

ch=1
i=1
sum=0

while [ $i -lt $num ] && [ $ch = 1 ]
do 
sum=` expr $i + $sum `

if [ $sum -lt 50 ]
then
i=` expr $i + 1 `

else 
ch=0

fi
done

if [ $ch = 1 ]
then
echo $sum

elif [ $ch = 0 ]
then
echo 'Sum too large to be printed'

fi
