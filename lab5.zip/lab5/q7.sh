clear

echo 'Enter the alphabet'
read alp

ls $alp*
