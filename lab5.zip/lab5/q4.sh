clear

find . -type f | xargs ls -ls | head -n 1 
