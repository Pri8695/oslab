hi ppl
ssup
