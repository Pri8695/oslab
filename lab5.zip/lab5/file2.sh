yo
howz u
hi ppl
ssup
hi ppl
ssup
